public class HW1 {
    public static void main(String[ ] args) {
        Automobile auto1 = new Automobile(1234, (float) 76586.2, 8, 29, 2020);
        Automobile auto2 = new Automobile(5678, (float) 5462.8, 6, 28, 2020);
        System.out.println("Automobile 1: ");
        System.out.println(auto1);
        System.out.println("Automobile 2: ");
        System.out.println(auto2);
    }
}
