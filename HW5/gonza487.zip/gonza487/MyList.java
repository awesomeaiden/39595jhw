public abstract interface MyList {
    public MyList next();

    public void printNode();
}
