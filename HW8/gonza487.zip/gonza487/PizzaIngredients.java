public class PizzaIngredients {

   public PizzaIngredients( ) {
      ingredients = "Ingredients are whatever you want";
   }

   @Override
   public String toString( ) {
      return ingredients;
   }

   private String ingredients;
}
