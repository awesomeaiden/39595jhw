public class ChicagoStyleCheese extends Pizza {
   public ChicagoStyleCheese(PizzaIngredients ingredients) {
      super("Chicago Style Cheese Pizza", ingredients);
   }
}
