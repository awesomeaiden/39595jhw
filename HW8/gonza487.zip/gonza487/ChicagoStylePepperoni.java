public class ChicagoStylePepperoni extends Pizza {
   public ChicagoStylePepperoni(PizzaIngredients ingredients) {
      super("Chicago Style Pepperoni Pizza", ingredients);
   }
}
