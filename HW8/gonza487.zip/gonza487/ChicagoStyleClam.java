public class ChicagoStyleClam extends Pizza {
   public ChicagoStyleClam(PizzaIngredients ingredients) {
      super("Chicago Style Clam Pizza", ingredients);
   }
}
