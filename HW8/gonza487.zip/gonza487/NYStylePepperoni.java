public class NYStylePepperoni extends Pizza {
   public NYStylePepperoni(PizzaIngredients ingredients) {
      super("NY Style Pepperoni Pizza", ingredients);
   }
}
