public class NYStyleClam extends Pizza {
   public NYStyleClam(PizzaIngredients ingredients) {
      super("NY Style Clam Pizza", ingredients);
   }
}
