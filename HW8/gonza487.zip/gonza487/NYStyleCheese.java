public class NYStyleCheese extends Pizza {
   public NYStyleCheese(PizzaIngredients ingredients) {
      super("NY Style Cheese Pizza", ingredients);
   }
}
