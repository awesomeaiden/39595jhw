package types;

public class Monster extends Creature {
    public Monster() {
        System.out.println("Creating a Monster");
    }
}
