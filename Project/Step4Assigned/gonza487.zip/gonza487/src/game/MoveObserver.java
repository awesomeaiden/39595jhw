package game;

public interface MoveObserver {
    abstract void observerUpdate(int moves);
}
