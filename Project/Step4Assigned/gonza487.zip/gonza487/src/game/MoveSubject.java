package game;

public interface MoveSubject {
    void registerMoveObserver(MoveObserver observer);
}
