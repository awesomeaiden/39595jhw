public class BlessCurseOwner extends ItemAction {
    public BlessCurseOwner(Item _owner) {
        super(_owner);
        System.out.println("Creating BlessCurseOwner: " + _owner);
    }
}
