public class BlessArmor extends ItemAction {
    public BlessArmor(Item _owner) {
        super(_owner);
        System.out.println("Creating BlessArmor: " + _owner);
    }
}
