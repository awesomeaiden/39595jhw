public class Magic extends Displayable {
    public Magic() {
        System.out.println("Creating a Magic");
    }
}
