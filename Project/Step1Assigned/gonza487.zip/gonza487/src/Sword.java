public class Sword extends Item {
    public Sword(String _name) {
        System.out.println("Creating a Sword: " + _name);
        this.setName(_name);
    }
}
