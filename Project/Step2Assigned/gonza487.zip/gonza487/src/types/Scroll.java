package types;

public class Scroll extends Item {
    public Scroll(String _name) {
        System.out.println("Creating a Scroll: " + _name);
        this.setName(_name);
    }

    @Override
    public char getChar() {
        return '?';
    }
}
