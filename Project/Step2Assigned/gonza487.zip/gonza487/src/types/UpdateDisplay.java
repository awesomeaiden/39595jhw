package types;

public class UpdateDisplay extends CreatureAction {
    private String name;

    public UpdateDisplay(String _name, Creature _owner) {
        super(_owner);
        System.out.println("Creating an UpdateDisplay: " + _name + _owner);
        name = _name;
    }
}
