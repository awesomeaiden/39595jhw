To access the original source for this go to https://github.com/trystan/AsciiPanel.

Prof. Midkiff
